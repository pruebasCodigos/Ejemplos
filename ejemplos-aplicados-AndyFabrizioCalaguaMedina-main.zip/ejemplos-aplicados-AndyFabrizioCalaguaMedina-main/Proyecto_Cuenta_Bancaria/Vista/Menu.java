package Vista;

public class Menu {
    public void imprimirMenu(){
        System.out.println("1. Crear Cliente");
        System.out.println("2. Crear Cuenta");
        System.out.println("3. Mostrar Clientes");
        System.out.println("4. Mostrar Cuentas");
        System.out.println("5. Salir");
    }
}
